let mappedX; //variable to hold mapped x position
let imageY = -200;

function setup() {
  createCanvas(400, 400);
  noCursor();
}

function preload(){
  img = loadImage('imhim.png');
}

function draw() {
  background(220);
  textSize(20);
  textAlign(CENTER);
  textFont("Courier")
  text("Them: who do you think you are", 200, 90)
   text("me: IM HIM!", 200, 250)
  mappedX = map(mouseX, 0, width, 0, width - 200, 1)
    image(img, mappedX,imageY,200,100);
   if (mouseIsPressed){
     imageY++;
   }
  if (imageY > 135){
    imageY = 135;
  }
}